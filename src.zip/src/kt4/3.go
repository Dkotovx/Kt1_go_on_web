
package animals

type Animal interface {
 Eat() string
 Sound() string
 Move() string
 Age() int
}

type Lion struct {
 age int
}

func (l *Lion) Sound() string {
 return "Лев Рычит"
}

func (l *Lion) Move() string {
 return "Лев шагает"
}

func (l *Lion) Age() int {
 return l.age
}

func (l *Lion) Eat() string {
 return "Других животных"
}


package animals

import (
 "fmt"
)

func InputAnimal() (Animal, error) {
 var animalType string
 var age int

 fmt.Print("Введите тип животного с большой буквы (Лев, Жираф, Змея): ")
 fmt.Scan(&animalType)
 fmt.Print("Введите возраст животного: ")
 fmt.Scan(&age)

 switch animalType {
 case "Лев":
  return &Lion{age: age}, nil
 case "Жираф":
  return &Giraffe{age: age}, nil
 case "Змея":
  return &Snake{age: age}, nil
 default:
  return nil, fmt.Errorf("неизвестный тип животного: %s", animalType)
 }
}

func PrintAnimalInfo(animal Animal) {
 fmt.Printf("Животное: %T\n", animal)
 fmt.Println("Звук:", animal.Sound())
 fmt.Println("Движение:", animal.Move())
 fmt.Printf("Возраст: %d\n", animal.Age())
 fmt.Println("Питание:", animal.Eat())
 fmt.Println()
}


package main

import (
 "fmt"

 "github.com/sirupsen/logrus"
 "github.com/your-username/animals" 
)

func main() {
 
 logrus.SetFormatter(&logrus.TextFormatter{
  FullTimestamp: true,
 })
 logrus.SetOutput(os.Stdout)

 var animals []animals.Animal
 var count int

 fmt.Print("Сколько животных вы хотите добавить? ")
 fmt.Scan(&count)

 for i := 0; i < count; i++ {
  fmt.Printf("Введите данные для животного %d:\n", i+1)
  animal, err := animals.InputAnimal()
  if err != nil {
   logrus.WithError(err).Error("Ошибка при вводе данных о животном")
   continue
  }
  animals = append(animals, animal)
 }

 fmt.Println("\nИнформация о животных:")
 for _, animal := range animals {
  animals.PrintAnimalInfo(animal)
 }
}