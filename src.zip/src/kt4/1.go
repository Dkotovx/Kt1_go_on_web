package animals

import (
 "fmt"
)

func InputAnimal() (Animal, error) {
 var animalType string
 var age int

 fmt.Print("Введите тип животного с большой буквы (Лев, Жираф, Змея): ")
 fmt.Scan(&animalType)
 fmt.Print("Введите возраст животного: ")
 fmt.Scan(&age)

 switch animalType {
 case "Лев":
  return &Lion{age: age}, nil
 case "Жираф":
  return &Giraffe{age: age}, nil
 case "Змея":
  return &Snake{age: age}, nil
 default:
  return nil, fmt.Errorf("неизвестный тип животного: %s", animalType)
 }
}

func PrintAnimalInfo(animal Animal) {
 fmt.Printf("Животное: %T\n", animal)
 fmt.Println("Звук:", animal.Sound())
 fmt.Println("Движение:", animal.Move())
 fmt.Printf("Возраст: %d\n", animal.Age())
 fmt.Println("Питание:", animal.Eat())
 fmt.Println()
}

