package main

import (
 "fmt"

 "github.com/sirupsen/logrus"
 "github.com/your-username/animals" 
)

func main() {
 
 logrus.SetFormatter(&logrus.TextFormatter{
  FullTimestamp: true,
 })
 logrus.SetOutput(os.Stdout)

 var animals []animals.Animal
 var count int

 fmt.Print("Сколько животных вы хотите добавить? ")
 fmt.Scan(&count)

 for i := 0; i < count; i++ {
  fmt.Printf("Введите данные для животного %d:\n", i+1)
  animal, err := animals.InputAnimal()
  if err != nil {
   logrus.WithError(err).Error("Ошибка при вводе данных о животном")
   continue
  }
  animals = append(animals, animal)
 }

 fmt.Println("\nИнформация о животных:")
 for _, animal := range animals {
  animals.PrintAnimalInfo(animal)
 }
}