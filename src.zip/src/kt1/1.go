package main

import "fmt"

type Book struct {
	Title  string
	Author string
	Year   int
}

func main() {
	book := Book{
		Title:  "Война и мир",
		Author: "Лев Толстой",
		Year:   1868,
	}
	fmt.Println("Название:", book.Title)
	fmt.Println("Автор:", book.Author)
	fmt.Println("Год издания:", book.Year)
}
